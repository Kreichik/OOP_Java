package Assignment2.Assignment_2_2;

public class Task6 {
    public static void main(String[] args) {
    }
    public static void universalMethod(){}
    public static void universalMethod(int a){}
    public static void universalMethod(int a, double b){}
    public static void universalMethod(int a, double b, double c){}
    public static void universalMethod(int a, double b, double c, double d){}
    public static void universalMethod(int a, double b, double c, double d, float f){}
    public static void universalMethod(int a, double b, double c, double d, float f, double d1){}
    public static void universalMethod(int a, float b, float c, float d){}
    public static void universalMethod(int a, float b, float c, float d, float f, double d1, double d2){}
    public static void universalMethod(int a, float b, float c, float d, float f, double d1, float f1, double d2){}
}
