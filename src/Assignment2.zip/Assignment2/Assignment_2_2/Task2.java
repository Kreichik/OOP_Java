package Assignment2.Assignment_2_2;

public class Task2 {
    public static void main(String[] args) {
        System.out.println("Я — поэт, зовусь я Цветик.");
        System.out.println("От меня вам всем приветик.");

    }
}
