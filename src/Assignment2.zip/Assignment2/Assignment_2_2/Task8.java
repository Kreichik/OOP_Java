package Assignment2.Assignment_2_2;

public class Task8 {
    public static void main(String[] args) {
        System.out.println(cube(2));
    }
    public static long cube(long num) {
        return num * num * num;
    }
}
