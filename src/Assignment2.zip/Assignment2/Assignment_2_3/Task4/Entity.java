package Assignment2.Assignment_2_3.Task4;

public class Entity {
    public void move(){
        System.out.println("Я передвигаюсь.");
    }
    public void eat(){
        System.out.println("Я ем.");
    }
}