package Assignment2.Assignment_2_3.Task4;

public class Human extends Entity{
    public void speak(){
        System.out.println("Я умею общаться.");
    }
}