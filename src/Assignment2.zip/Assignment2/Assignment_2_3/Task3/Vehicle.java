package Assignment2.Assignment_2_3.Task3;

public class Vehicle {
    double maxSpeed;
}