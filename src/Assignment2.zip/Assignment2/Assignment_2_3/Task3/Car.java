package Assignment2.Assignment_2_3.Task3;

public class Car extends Vehicle {
    int wheelCount;
    double weight;
}