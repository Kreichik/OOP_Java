package Assignment2.Assignment_2_3;

import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        String text1 = new String();
        String text2 = new String();
        String text3 = new String();
        String text4 = new String();
        String text5 = new String();
        String text6 = new String();
        String text7 = new String();
        String text8 = new String();
        String text9 = new String();
        String text10 = new String();
        int[] num1 = new int[]{};
        int[] num2 = new int[]{};
        int[] num3 = new int[]{};
        int[] num4 = new int[]{};
        int[] num5 = new int[]{};
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);


    }
}
