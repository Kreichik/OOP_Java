package Assignment2.Assignment_2_3.Task2;

public class Woman extends Human {
}
