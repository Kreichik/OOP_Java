package Assignment2.Assignment_2_1;

public class Task1 {
    public static void main(String[] args) {
        int intArray[] = new int[10];
        double doubleArray[] = new double[10];
    }
}
